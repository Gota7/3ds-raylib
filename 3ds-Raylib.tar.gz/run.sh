make
/usr/bin/flatpak run --branch=stable --arch=x86_64 --command=citra-qt --file-forwarding org.citra_emu.citra 3ds-Raylib.3dsx
